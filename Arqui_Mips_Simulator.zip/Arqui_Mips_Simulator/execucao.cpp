#include "execucao.h"

Execucao::Execucao()
{

}
