#ifndef BARREIRAMEMWB_H
#define BARREIRAMEMWB_H



class BarreiraMemWB
{
private:
    int endereco;
    int dado;

public:
    BarreiraMemWB();
    int getEndereco() const;
    void setEndereco(int value);
    int getDado() const;
    void setDado(int value);

};

#endif // BARREIRAMEMWB_H


