#include "executa.h"

Executa::Executa()
{

}
