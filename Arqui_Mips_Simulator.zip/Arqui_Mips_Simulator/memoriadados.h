#ifndef MEMORIADADOS_H
#define MEMORIADADOS_H
#include "instrucao.h"
#include "barreiramemwb.h"
#include <QList>


class MemoriaDados
{
private:
    QList<int> memoria;//memoria
    BarreiraMemWB *barreiraOut;
public:
    MemoriaDados();
    MemoriaDados(BarreiraMemWB *bp);
     void Executar(int end);
  //   void Executar(int dado);
    // void Executar(bool W_B);
};

#endif // MEMORIADADOS_H
