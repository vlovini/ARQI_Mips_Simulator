#include "memoriadados.h"

MemoriaDados::MemoriaDados()
{

}


MemoriaDados::MemoriaDados(BarreiraMemWB *bp)
{
    barreiraOut = bp;
    for(int i=0;i<100;i++)
    {
        memoria.append(0);
    }
}

void MemoriaDados::Executar(int end)
{

    memoria[end] = dado;
}

