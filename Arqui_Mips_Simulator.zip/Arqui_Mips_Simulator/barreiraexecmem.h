#ifndef BARREIRAEXECMEM_H
#define BARREIRAEXECMEM_H


class BarreiraExecMem
{
public:
    BarreiraExecMem();
};

#endif // BARREIRAEXECMEM_H