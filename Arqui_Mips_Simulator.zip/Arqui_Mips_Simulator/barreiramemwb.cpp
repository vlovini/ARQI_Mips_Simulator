#include "barreiramemwb.h"


    int BarreiraMemWB::getEndereco() const
    {
        return endereco;
    }

    void BarreiraMemWB::setEndereco(int value)
    {
        endereco = value;
    }

    int BarreiraMemWB::getDado() const
    {
        return dado;
    }

    void BarreiraMemWB::setDado(int value)
    {
        dado = value;
    }


