#ifndef EXECUCAO_H
#define EXECUCAO_H


class Execucao
{
public:
    Execucao();
};

#endif // EXECUCAO_H