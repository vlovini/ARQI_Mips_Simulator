#include "barreiraexecmem.h"

BarreiraExecMem::BarreiraExecMem()
{

}
