#ifndef EXECUTA_H
#define EXECUTA_H


class Executa
{
public:
    Executa();
};

#endif // EXECUTA_H
